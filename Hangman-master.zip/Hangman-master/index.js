"use strict";
const difficultySelection = document.getElementById("difficultySelection");
const difficulty = document.getElementById("difficulty");
const welcomeScreen = document.getElementById("welcomeScreen");
const guessButton = document.getElementById("guessButton");
const gameScreen = document.getElementById("gameScreen");
const resetGame = document.getElementById("resetGame")
const gameForm = document.getElementById("gameForm");
const userInput = document.getElementById("userInput");
const canvas = document.getElementById("canvas");
const context = canvas.getContext("2d");
const hangManWord = document.getElementById("hangManWord");
var currentGuesses = [];
var correctGuesses = 0;
var incorrectGuesses = 0;




let game;


async function fetchRandomWord(difficulty) {
    
    const response = await fetch(`https://hangman-micro-service-bpblrjerwh.now.sh/?difficulty=${difficulty}`);
    const wordObject = await response.json();
    console.log(wordObject.word);
    return wordObject.word;
  
  } 
class HangMan{
    constructor() {}
    async setup() {
        this.randomWord = await fetchRandomWord();
        this.numberOfGuesses = 0;
        console.log(this.randomWord)
        this.wordArray = Array.from(this.randomWord);
        console.log(`here is the array: ` + this.wordArray)
        hangManWord.innerHTML ="";
        for(var h = 0; h<this.wordArray.length; h++){
            if(this.wordArray[h] in currentGuesses){
                hangManWord.innerHTML += this.wordArray[h] +" ";
            }
            else{hangManWord.innerHTML += `  -`}
        }
        
    }
   
    
    
    guess(val) {
        this.numberOfGuesses += 1;
        return this.randomWord === val;
    }

}


function drawHangMan(){
//head
if(incorrectGuesses>=1){
    context.beginPath();
        context.fillStyle="black"
        context.arc(150, 45, 25, 0, 2 * Math.PI);
        context.stroke();
        context.closePath();
}
//body
if(incorrectGuesses>=2){
    context.beginPath();
        context.moveTo(150,70);
        context.lineTo(150,130);
        context.stroke();
}
//right arm
if(incorrectGuesses>=3){
    context.beginPath();
        context.moveTo(150,80);
        context.lineTo(185,100);
        context.stroke();
}
//left arm
if(incorrectGuesses>=4){
    context.beginPath();
        context.moveTo(150,80);
        context.lineTo(115,105);
        context.stroke();
    
}
//left leg
if(incorrectGuesses>=5){
    context.beginPath();
        context.moveTo(150,130);
        context.lineTo(50,250);
        context.stroke();}

//right leg
if(incorrectGuesses>=6){
    context.beginPath();
        context.moveTo(150,130);
        context.lineTo(250,250);
        context.stroke();
}
//face
if(incorrectGuesses>=7){
context.beginPath();
context.arc(150, 60, 10, 0.15*Math.PI,0.85*Math.PI,true);
context.moveTo(140,40);
context.lineTo(135,50);
context.moveTo(160,40);
context.lineTo(165,50)
context.stroke();
}

}



difficultySelection.addEventListener("submit", async function(difficultySelectionClickEvent){
difficultySelectionClickEvent.preventDefault();

console.log("User clicked the start button");

game = new HangMan();
await game.setup();
console.log(game);
welcomeScreen.className = "hidden";
gameScreen.className ="";


});


gameForm.addEventListener("submit", function(gameFormSubmitEvent){
gameFormSubmitEvent.preventDefault();
if(!userInput.value){
    return alert(`You have to provide an input!`);
}

const guess = (userInput.value);


    if (
      !guess ||
      typeof guess !== `string` ||
      !/[a-z]/.test(guess.toLowerCase())
    ) {
      return alert(`You must provide a valid input`);
    }

    if (guess.length > 1) {
      return alert(`You are only supposed to enter one letter at a time`);
    }
    
    if (currentGuesses.includes(guess)) {
      return alert(`You have already guessed the letter ` + guess);
    }
    
    var repeatingLetters = [new Set(game.wordArray)];
    for (var b=0; b<repeatingLetters.length; b++){
        if(repeatingLetters[b] in currentGuesses || game.wordArray.includes(guess))
        {correctGuesses++;
        }
        else{incorrectGuesses++;}
    }
    drawHangMan();
    if(game.wordArray.length == correctGuesses){return alert("You Win!!!")
    };
    if(incorrectGuesses>=7){return alert("You lose!! :( The word was: " + game.randomWord)}

   
    currentGuesses.push(guess);
    currentGuesses.sort();
    game.numberOfGuesses++;
    console.log("number of Guesses: " + game.numberOfGuesses)
    console.log("correct guesses: " + correctGuesses)
    console.log("bad guesses: " + incorrectGuesses)
    console.log(game.wordArray.length + "length of array")

    return alert(`Here are the letters you've used: ` +currentGuesses);

}

);


